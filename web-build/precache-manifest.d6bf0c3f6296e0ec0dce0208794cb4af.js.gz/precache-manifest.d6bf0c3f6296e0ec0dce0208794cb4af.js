self.__precacheManifest = [
  {
    "revision": "e20945d7c929279ef7a6f1db184a4470",
    "url": "/./fonts/Foundation.ttf"
  },
  {
    "revision": "a09e9ed1c29e4693c5e9",
    "url": "/static/js/app.e905eb76.chunk.js"
  },
  {
    "revision": "f16959773581a57813f0",
    "url": "/static/js/runtime~app.91065de9.js"
  },
  {
    "revision": "004c2bbb035d8d06bb830efc4673c886",
    "url": "/static/media/star.004c2bbb.png"
  },
  {
    "revision": "2327736b3ea09c41abfb69be1221f430",
    "url": "/static/media/heart.2327736b.png"
  },
  {
    "revision": "51671417ef20e0bbc32f0a2bc6edfa95",
    "url": "/static/media/rocket.51671417.png"
  },
  {
    "revision": "a7b9dc9de5f8f1fb1afbef917619a5ac",
    "url": "/static/media/bell.a7b9dc9d.png"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "/./fonts/SimpleLineIcons.ttf"
  },
  {
    "revision": "ab620d40bac2274beda7aa7a71ac57a0",
    "url": "/index.html"
  },
  {
    "revision": "6901565a1abd41e00bc1e778e7f63c22",
    "url": "/manifest.json"
  },
  {
    "revision": "d0c694b562b2208635f250762cd7fc79",
    "url": "/serve.json"
  },
  {
    "revision": "0215b44b31e7fa6c4edb",
    "url": "/static/js/2.1ee96992.chunk.js"
  },
  {
    "revision": "7a7bc7ead25db795e58b336f04d2624c",
    "url": "/favicon.ico"
  },
  {
    "revision": "a37b0c01c0baf1888ca812cc0508f6e2",
    "url": "/./fonts/MaterialIcons.ttf"
  },
  {
    "revision": "5a293a273bee8d740a045d9922b9a9ae",
    "url": "/./fonts/MaterialCommunityIcons.ttf"
  },
  {
    "revision": "b2e0fc821c6886fb3940f85a3320003e",
    "url": "/./fonts/Ionicons.ttf"
  },
  {
    "revision": "872545dde71de3842234bf6afe80c4cb",
    "url": "/./fonts/FontAwesome5_Solid.ttf"
  },
  {
    "revision": "c6aef942e3668158ec29d4adcb2e768f",
    "url": "/./fonts/FontAwesome5_Brands.ttf"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/./fonts/FontAwesome.ttf"
  },
  {
    "revision": "6beba7e6834963f7f171d3bdd075c915",
    "url": "/./fonts/Feather.ttf"
  },
  {
    "revision": "744ce60078c17d86006dd0edabcd59a7",
    "url": "/./fonts/Entypo.ttf"
  },
  {
    "revision": "3a2ba31570920eeb9b1d217cabe58315",
    "url": "/./fonts/AntDesign.ttf"
  }
];