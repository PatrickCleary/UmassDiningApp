
--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`food`,`hall`,`meal`,`category`);

--
-- Indexes for table `nutritionInfo`
--
ALTER TABLE `nutritionInfo`
  ADD PRIMARY KEY (`food`);

--
-- Indexes for table `nutritionInfoUpdated`
--
ALTER TABLE `nutritionInfoUpdated`
  ADD PRIMARY KEY (`food`,`category`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`token`);
